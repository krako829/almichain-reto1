# Almi Bites · Despliegue en AWS con Terraform

Reto 1 Almi-Chain (ASIR 1). Despliega la web del restaurante en AWS Academy con **dominio DuckDNS**, **HTTPS (Let's Encrypt)** y **geolocalización**, todo como código con Terraform.

## Qué crea

```
Internet
   │
   ▼  almichain2.duckdns.org  ──►  IP elástica (fija)
┌──────────────── VPC 10.0.0.0/16 ────────────────┐
│  Subred pública 10.0.1.0/24  ── Internet Gateway │
│   ┌───────────────────────────────┐              │
│   │ EC2 Ubuntu 24.04 (t3.micro)    │◄── SSH: Terraform sube web/
│   │ Nginx + Certbot (Let's Encrypt)│              │
│   │ SG: 80, 443, 22                │              │
│   └───────────────────────────────┘              │
└──────────────────────────────────────────────────┘
```

| Fichero | Qué hace |
|---|---|
| `versions.tf` | Proveedores (AWS, TLS para la clave SSH, local) y región |
| `variables.tf` | Datos configurables (dominio, token, correo…) |
| `main.tf` | VPC, subred, IGW, rutas, grupo de seguridad, clave SSH, IP elástica, EC2 y subida de la web por SSH |
| `user_data.sh.tftpl` | Script que se ejecuta al arrancar la EC2: instala Nginx, actualiza DuckDNS y pide el certificado HTTPS |
| `outputs.tf` | Muestra la URL, la IP y el comando SSH al terminar |
| `web/` | La página (index.html, estilos.css, geo.js, img/) |

## 1. Preparación (solo la primera vez)

### Instalar Terraform

**Zorin OS / Ubuntu:**
```bash
wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install -y terraform
terraform -version
```

**Windows:** `winget install Hashicorp.Terraform` (y abrir una terminal nueva).

### Crear el dominio en DuckDNS

1. Entra en <https://www.duckdns.org> e inicia sesión (con Google o GitHub).
2. El dominio del reto es `almichain2.duckdns.org`: inicia sesión con la cuenta de DuckDNS donde está creado el subdominio `almichain2`.
3. Copia el **token** de **esa misma cuenta** (aparece arriba). Con el token de otra cuenta DuckDNS responde `KO`. La IP da igual, Terraform la cambia sola.

## 2. Credenciales de AWS Academy (cada vez que inicies el lab)

Las credenciales del Learner Lab **caducan a las ~4 horas**, así que esto se repite en cada sesión:

1. AWS Academy → Learner Lab → **Start Lab** (espera a que el punto se ponga verde).
2. **AWS Details** → en *AWS CLI* pulsa **Show** y copia todo el bloque (`[default]`, `aws_access_key_id`, `aws_secret_access_key`, `aws_session_token`).
3. Pégalo en el fichero de credenciales (sustituyendo lo que haya):
   - Linux: `~/.aws/credentials` → `mkdir -p ~/.aws && nano ~/.aws/credentials`
   - Windows: `C:\Users\TU_USUARIO\.aws\credentials`

Si Terraform da `ExpiredToken` o `InvalidClientTokenId`, es que toca volver a copiarlas.

## 3. Configurar

```bash
cd almibites-terraform
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars        # pon el token de DuckDNS y tu correo (el subdominio ya es almichain2)
```

## 4. Desplegar

```bash
terraform init      # descarga los proveedores (la primera vez y si cambia versions.tf)
terraform plan      # muestra lo que va a crear (13 recursos)
terraform apply     # escribe "yes"
```

El `apply` tarda **unos 5 minutos**: al final se queda esperando a que la máquina instale Nginx, actualice DuckDNS y consiga el certificado, y entonces sube la web por SSH. Cuando veas `==> LISTO: https://almichain2.duckdns.org` y `Apply complete!`, abre `https://almichain2.duckdns.org` → debe salir el candado, y `http://` debe redirigir a `https://`.

Para comprobar la geolocalización: sección *Dónde estamos* → botón **¿A cuánto estoy?** → aceptar el permiso de ubicación.

## 5. Cambiar la web

Edita lo que quieras dentro de `web/` y haz:

```bash
terraform apply
```

Terraform detecta que ha cambiado algo en `web/` y vuelve a subir la carpeta por SSH (unos segundos). No se recrea la máquina ni el certificado.

## 6. Apagar / borrar

- Al acabar la sesión del lab, AWS Academy **apaga la EC2** sola; al volver a iniciar el lab se enciende y, como la IP es elástica, el dominio sigue funcionando.
- Para **borrarlo todo** (por ejemplo al terminar el reto):
  ```bash
  terraform destroy
  ```

⚠️ **Guardad la carpeta con el `terraform.tfstate`** (en un USB o en Drive, no en un GitHub público porque lleva el token). Sin ese fichero Terraform no sabe qué creó y no podrá borrarlo ni modificarlo. Que despliegue siempre **la misma persona** desde la misma carpeta.

## Problemas típicos

| Problema | Solución |
|---|---|
| `ExpiredToken` / `InvalidClientTokenId` | Volver a copiar las credenciales de *AWS Details* |
| La web va por HTTP pero no por HTTPS | Esperar 5 min. Si sigue, entrar por SSH y mirar el log (abajo) |
| `too many certificates already issued` | Let's Encrypt deja 5 certificados/semana por dominio. Poned `certbot_staging = true` mientras hacéis pruebas de destroy/apply, y a `false` para la versión final |
| `timeout - last error: dial tcp ...:22` al subir la web | La red desde la que lanzas Terraform bloquea SSH (puerto 22). Prueba desde otra red (casa o datos del móvil) y repite `terraform apply` |
| `InvalidKeyPair.Duplicate` | Ya existe una clave `almibites-key` en la cuenta (de un despliegue anterior). Bórrala en EC2 → Pares de claves y repite |
| La geolocalización no responde | Solo funciona por **https://**; revisad que el navegador tenga permiso de ubicación |

**Ver el log de instalación** (Terraform deja la clave `almibites-key.pem` en la carpeta del proyecto):
```bash
ssh -i almibites-key.pem ubuntu@IP_PUBLICA
sudo tail -n 50 /var/log/almibites-setup.log
```

**Repetir solo el certificado** (desde dentro de la máquina):
```bash
sudo certbot --nginx -d almichain2.duckdns.org --redirect
```

**Recrear solo la máquina** (por ejemplo si cambiáis el dominio):
```bash
terraform apply -replace=aws_instance.web
```

## Cómo cumple el reto

- **Infraestructura como código:** toda la infraestructura (red, seguridad, claves, IP y servidor) y la publicación de la web está en Terraform; se crea con `apply` y se borra con `destroy`.
- **Dominio:** DuckDNS, actualizado automáticamente con la IP elástica.
- **HTTPS:** certificado gratuito de Let's Encrypt con Certbot, redirección HTTP → HTTPS y renovación automática.
- **Geolocalización:** mapa de OpenStreetMap con la ubicación del restaurante + botón que usa la API de geolocalización del navegador para calcular la distancia y la ruta (esta API solo funciona sobre HTTPS).
- **Coste 0 €:** solo se usan los créditos de AWS Academy (t3.micro con 8 GB de disco e IP elástica).

> Nota: la primera versión subía la web a un bucket S3, pero AWS Academy bloquea `s3:GetBucketObjectLockConfiguration` y el proveedor de AWS de Terraform no puede gestionar buckets en el lab. Por eso la web se sube por SSH.
